/**
 * preload：只暴露白名单 API。
 * 渲染层拿不到 Node，也拿不到 ipcRenderer 本体。
 */
const {contextBridge, ipcRenderer} = require('electron');

contextBridge.exposeInMainWorld('lc2', {
  /* ---- 数据 ---- */
  getData: () => ipcRenderer.invoke('lc2:getData'),
  getConfig: () => ipcRenderer.invoke('lc2:getConfig'),
  checkUpdate: () => ipcRenderer.invoke('lc2:checkUpdate'),
  openExternal: (url) => ipcRenderer.invoke('lc2:openExternal', url),

  /* ---- 投稿草稿 ---- */
  submitMode: (on) => ipcRenderer.invoke('lc2:submitMode', !!on),
  submitBuild: (payload) => ipcRenderer.invoke('lc2:submitBuild', payload),

  /* ---- 面板 ---- */
  /** 主进程通知面板打开/关闭（只有 mode=panel 的窗口会收到） */
  onPanel: (cb) => {
    const h = (_e, state) => cb(state);
    ipcRenderer.on('lc2:panel', h);
    return () => ipcRenderer.removeListener('lc2:panel', h);
  },
  /** 主进程转发的按键名（ArrowUp / Enter / f …） */
  onKey: (cb) => {
    const h = (_e, key) => cb(key);
    ipcRenderer.on('lc2:key', h);
    return () => ipcRenderer.removeListener('lc2:key', h);
  },
  /** 请求切换面板（气泡点击 / Esc 到底） */
  requestToggle: () => ipcRenderer.send('lc2:toggle'),
  /** 请求关闭面板 */
  requestClose: () => ipcRenderer.send('lc2:closePanel'),

  /* ---- 用户印象 / 评价（本地保存，后续用于标签整理） ---- */
  notesGet: () => ipcRenderer.invoke('lc2:notes:get'),
  notesSet: (buildId, text) => ipcRenderer.invoke('lc2:notes:set', { buildId, text }),

  /* ---- 搜索/筛选时临时获焦（输入框需要键盘） ---- */
  searchFocus: (on) => ipcRenderer.send('lc2:searchFocus', !!on),
  /** 弹层占用 Esc：输入控件获焦时面板热键被注销，这里单独把 Esc 抢回来 */
  modalEscape: (on) => ipcRenderer.send('lc2:modalEscape', !!on),
  /** 面板休眠（被点到外部后不接收键盘）→ 点击面板时唤醒 */
  activatePanel: () => ipcRenderer.send('lc2:activatePanel'),
  onDormant: (cb) => {
    const h = (_e, v) => cb(v);
    ipcRenderer.on('lc2:dormant', h);
    return () => ipcRenderer.removeListener('lc2:dormant', h);
  },

  /* ---- 置顶（点击外部不收起） ---- */
  pinToggle: () => ipcRenderer.send('lc2:pinToggle'),
  onPin: (cb) => {
    const h = (_e, pinned) => cb(pinned);
    ipcRenderer.on('lc2:pin', h);
    return () => ipcRenderer.removeListener('lc2:pin', h);
  },

  /* ---- 气泡拖拽 ---- */
  dragStart: (sx, sy) => ipcRenderer.send('lc2:dragStart', {sx, sy}),
  dragMove: (sx, sy) => ipcRenderer.send('lc2:dragMove', {sx, sy}),
  dragEnd: () => ipcRenderer.send('lc2:dragEnd'),

  /* ---- 面板拖拽（与气泡相互独立） ---- */
  panelDragStart: (sx, sy) => ipcRenderer.send('lc2:panelDragStart', {sx, sy}),
  panelDragMove: (sx, sy) => ipcRenderer.send('lc2:panelDragMove', {sx, sy}),
  panelDragEnd: () => ipcRenderer.send('lc2:panelDragEnd'),

  /* ---- 面板缩放（自定义边缘手柄） ---- */
  panelResizeStart: (sx, sy, dir) => ipcRenderer.send('lc2:panelResizeStart', { sx, sy, dir }),
  panelResizeEnd: () => ipcRenderer.send('lc2:panelResizeEnd'),
  setPanelSize: (width, height) => ipcRenderer.send('lc2:setPanelSize', { width, height }),
});
