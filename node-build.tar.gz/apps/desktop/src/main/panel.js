/**
 * 面板窗口控制器
 *
 * 把「面板窗口」的完整生命周期收在这一层：
 *   创建 / 显隐 / 淡入淡出 / 圆角方案 / 拖拽 / 休眠 / 搜索焦点 / 外部点击收起
 *
 * 依赖全部从外部注入（Electron、原生 shadow helper、配置、几何、热键），
 * 因此可以用假窗口在 node --test 里验证主要流程。
 */
const shapeRounded = require('./shape');

function createPanel(deps) {
  const {
    BrowserWindow,
    screen,
    panelShadow,
    configStore,
    geometry,
    getBubbleBounds,
    enablePanelKeys,
    disablePanelKeys,
    isQuitting,
    log,
    onPageLoaded,
    paths,
    PANEL,
    PANEL_RADIUS,
    SHADOW_PAD,
    WIN_MODE,
    PANEL_CORNER_PREF,
    USE_PANEL_SHADOW,
    USE_SHAPE_CLIP,
    fade,
  } = deps;

  /**
   * 置顶级别：floating（普通 topmost）而不是 screen-saver。
   * screen-saver 会盖住系统截图 / 微信截图的框选层，导致无法在面板内部起手框选。
   */
  const TOPMOST_LEVEL = deps.topmostLevel || 'floating';

  let win = null;
  let open = false;
  let pinned = false;
  let dormant = false;
  let focusTimer = null;
  /** 圆角模式：dwm（Win11 系统圆角）| shape（Win10 回退裁剪）| null（探测中） */
  let cornersMode = null;
  let dragState = null;
  let resizeState = null;
  let resizeTimer = null;
  let resizeCursorScale = 1;
  let sessionSize = null;
  let windowSize = { width: PANEL.w, height: PANEL.h };
  let submitModeBounds = null;
  const RESIZE_DIRS = new Set(['n','s','e','w','ne','nw','se','sw']);
  let dragMoveCount = 0;
  let dragTimer = null;
  let dragCursorScale = 1;
  let lastDragPos = null;

  function stopDragTimer() {
    if (dragTimer) { clearInterval(dragTimer); dragTimer = null; }
  }

  /**
   * Windows 上把 window 从 skipTaskbar 变成 focusable 后，
   * 系统会重新给它创建任务栏按钮（用户反馈：操作搜索/筛选时底部多一个图标）。
   * 每次焦点变化后重新声明 skipTaskbar=true 来清掉按钮。
   */
  function keepOffTaskbar() {
    if (!win || win.isDestroyed()) return;
    try { win.setSkipTaskbar(true); } catch {}
  }

  /* ---------------- 圆角 ---------------- */
  function applyShape() {
    if (!win || win.isDestroyed()) return;
    if (cornersMode === 'dwm') return; // Win11：系统圆角，不裁剪
    if (cornersMode === null) return; // 探测中，等结果
    // Win10 回退：窗口区域裁剪（阴影层会补一圈抗锯齿轮廓盖住阶梯）
    const b = win.getBounds();
    shapeRounded(win, b.width, b.height, PANEL_RADIUS, log);
  }

  function setupCorners() {
    if (!win) return;
    const forced = (process.env.LC2_PANEL_CORNERS || 'auto').toLowerCase();

    if (forced === 'shape') {
      cornersMode = 'shape';
      if (USE_PANEL_SHADOW) panelShadow.setFill(true);
      applyShape();
      sendPanelState();
      log.debug?.('panel corners: shape (forced)');
      return;
    }

    let hwndValue = '0';
    try {
      const buf = win.getNativeWindowHandle();
      hwndValue = buf.length >= 8 ? buf.readBigUInt64LE(0).toString() : String(buf.readUInt32LE(0));
    } catch (e) {
      log('getNativeWindowHandle failed:', e.message);
    }

    panelShadow.setPanelCorner(hwndValue, PANEL_CORNER_PREF).then((ok) => {
      if (!win || win.isDestroyed()) return;
      if (ok) {
        cornersMode = 'dwm';
        try { win.setShape([]); } catch {}
        log.debug?.(
          'panel corners: dwm pref=' + PANEL_CORNER_PREF,
          PANEL_CORNER_PREF === 1 ? 'square' : (PANEL_CORNER_PREF === 2 ? 'round' : 'round-small')
        );
      } else {
        cornersMode = 'shape';
        if (USE_PANEL_SHADOW) panelShadow.setFill(true);
        applyShape();
        log.debug?.('panel corners: shape fallback (win10/7)');
      }
      sendPanelState();
    });
  }

  /* ---------------- 淡入淡出 ---------------- */
  const FADE = fade || { enabled: true, inMs: 150, outMs: 110 };
  let fadeSupported = null; // null = 未探测
  let fadeTimer = null;

  function stopFade() {
    if (fadeTimer) {
      clearInterval(fadeTimer);
      fadeTimer = null;
    }
  }

  function probeFadeSupport(target) {
    if (fadeSupported !== null) return fadeSupported;
    fadeSupported = false;
    if (!FADE.enabled || typeof target.setOpacity !== 'function' || typeof target.getOpacity !== 'function') return false;
    try {
      target.setOpacity(0.02);
      fadeSupported = target.getOpacity() < 0.5; // 读不回来说明系统忽略透明度
      target.setOpacity(1);
    } catch {
      fadeSupported = false;
    }
    log.debug?.('panel fade supported =', fadeSupported);
    return fadeSupported;
  }

  function fadeIn(target) {
    // Win11 系统圆角依赖非 layered 窗口：一旦调用 setOpacity，窗口会变成 layered，
    // DWM 圆角可能失效。所以圆角走 DWM 时（或还在探测中）跳过窗口透明度动画。
    if (cornersMode !== 'shape') return;
    if (!probeFadeSupport(target)) {
      try { target.setOpacity(1); } catch {}
      return;
    }
    stopFade();
    const steps = Math.max(4, Math.round(FADE.inMs / 16));
    let i = 0;
    target.setOpacity(0);
    fadeTimer = setInterval(() => {
      i += 1;
      const t = i / steps;
      const eased = 1 - Math.pow(1 - t, 3); // ease-out cubic
      try { target.setOpacity(Math.min(1, eased)); } catch {}
      if (i >= steps) {
        stopFade();
        try { target.setOpacity(1); } catch {}
      }
    }, 16);
  }

  function fadeOut(target, done) {
    if (cornersMode !== 'shape') {
      done();
      return;
    }
    if (!probeFadeSupport(target)) {
      try { target.setOpacity(1); } catch {}
      done();
      return;
    }
    stopFade();
    const steps = Math.max(3, Math.round(FADE.outMs / 16));
    let i = 0;
    fadeTimer = setInterval(() => {
      i += 1;
      const t = i / steps;
      const eased = Math.pow(1 - t, 2); // ease-in quad
      try { target.setOpacity(Math.max(0, eased)); } catch {}
      if (i >= steps) {
        stopFade();
        done();
      }
    }, 16);
  }

  /* ---------------- 位置 ---------------- */
  function setWindowBounds(bounds) {
    win.setBounds(bounds, false);
    windowSize = { width: bounds.width, height: bounds.height };
  }

  function resolveBounds() {
    const bubble = getBubbleBounds();
    const displays = screen.getAllDisplays();
    const nearestToBubble = screen.getDisplayMatching
      ? screen.getDisplayMatching(bubble)
      : screen.getDisplayNearestPoint({ x: bubble.x, y: bubble.y });
    return geometry.resolvePanelBounds(
      configStore.state.panel,
      bubble,
      displays,
      nearestToBubble
    );
  }

  function sideOfPanel() {
    const b = getBubbleBounds();
    return win.getBounds().x < b.x ? 'left' : 'right';
  }

  function sendPanelState() {
    if (!win || win.isDestroyed()) return;
    try {
      const cornerRadius = cornersMode === 'shape' ? PANEL_RADIUS
        : (PANEL_CORNER_PREF === 1 ? 0 : (PANEL_CORNER_PREF === 2 ? 8 : 4));
      win.webContents.send('lc2:panel', { open, pinned, side: sideOfPanel(), frame: cornersMode, cornerRadius });
    } catch (e) {
      log('send panel state failed:', e.message);
    }
  }

  /* ---------------- 阴影 ---------------- */
  function showPanelShadow() {
    if (!USE_PANEL_SHADOW || !win) return;
    const b = win.getBounds();
    panelShadow
      .ensureStarted({ panelW: PANEL.w, panelH: PANEL.h, radius: PANEL_RADIUS, pad: SHADOW_PAD })
      .then((ok) => {
        if (!ok || !open) return;
        panelShadow.setAlpha(0);
        panelShadow.showAt(b.x - SHADOW_PAD, b.y - SHADOW_PAD);
        panelShadow.fadeTo(255, FADE.inMs);
        // 阴影窗口更晚创建，会压在最上层；显式把面板抬回上面
        try { win.setAlwaysOnTop(true, TOPMOST_LEVEL); } catch {}
      });
  }

  /* ---------------- 休眠 / 唤醒 ---------------- */
  function cancelFocusTimer() {
    clearTimeout(focusTimer);
    focusTimer = null;
  }

  function focusPanel() {
    try {
      win.setFocusable(true);
      win.focus();
      win.webContents.focus();
    } catch (e) {
      log('panel focus failed:', e.message);
    }
    keepOffTaskbar();
  }

  function enterDormant() {
    if (!win || win.isDestroyed() || !open || dormant) return;
    dormant = true;
    cancelFocusTimer();
    disablePanelKeys();
    try { win.setFocusable(false); } catch {}
    try { win.webContents.send('lc2:dormant', true); } catch {}
    log.debug?.('panel dormant（不接收键盘，点击面板唤醒）pinned =', pinned);
  }

  function exitSearchFocus() {
    cancelFocusTimer();
    if (!win || win.isDestroyed()) return;
    keepOffTaskbar();
    // 只恢复不可聚焦 + 重新注册热键；不要 hide/show，否则会打断点击
    try { win.setFocusable(false); } catch {}
    if (open && !dormant) enablePanelKeys();
  }

  function wake() {
    if (!win || win.isDestroyed() || !open || !dormant) return;
    cancelFocusTimer();
    dormant = false;
    log.debug?.('panel activate（点击唤醒）pinned =', pinned);
    focusPanel();
    if (win.webContents) win.webContents.send('lc2:dormant', false);
    focusTimer = setTimeout(() => {
      focusTimer = null;
      if (!win || win.isDestroyed() || !open || dormant) return;
      const focused = win.isFocused();
      log.debug?.('panel activate: focused=', focused);
      if (!focused) {
        // 唤醒失败 → 退回"不抢焦点但可用热键"模式，避免键盘完全失效
        enablePanelKeys();
        win.webContents.send('lc2:dormant', false);
        log('panel activate failed → 回退到热键模式');
      }
    }, 150);
  }

  function setSearchFocus(on) {
    if (!win || win.isDestroyed()) return;
    if (!on) {
      exitSearchFocus();
      return;
    }
    if (!open) return;
    cancelFocusTimer();
    dormant = false;
    win.webContents.send('lc2:dormant', false);
    disablePanelKeys();
    focusPanel();
    focusTimer = setTimeout(() => {
      focusTimer = null;
      if (!win || win.isDestroyed() || !open || dormant) return;
      keepOffTaskbar();
      log.debug?.('search focus on: focusable=', win.isFocusable(), 'focused=', win.isFocused());
      if (!win.isFocused()) {
        focusPanel();
      }
    }, 120);
  }

  /* ---------------- 显隐 ---------------- */
  function showBounds() {
    const base = resolveBounds();
    if (!sessionSize) return base;
    let { width, height } = sessionSize;
    let x = base.x, y = base.y;
    try {
      const wa = screen.getDisplayMatching(base).workArea;
      width = Math.min(width, wa.width - 8);
      height = Math.min(height, wa.height - 8);
      x = Math.max(wa.x, Math.min(x, wa.x + wa.width - width));
      y = Math.max(wa.y, Math.min(y, wa.y + wa.height - height));
    } catch {}
    return { x, y, width, height };
  }

  function show() {
    if (!win || open) return;
    open = true;
    dormant = false;
    setWindowBounds(showBounds());
    applyShape();
    fadeIn(win);
    win.showInactive(); // 显示但不抢焦点
    try { win.setFocusable(false); } catch {}
    keepOffTaskbar();
    showPanelShadow();
    // 告诉渲染层面板从气泡哪一侧展开（决定进场动画的方向原点）
    sendPanelState();
    enablePanelKeys();
    log.debug?.('panel open');
  }

  function destroy() {
    stopDragTimer();
    stopResizeTimer();
    if (win && !win.isDestroyed()) {
      try { win.destroy(); } catch {}
    }
    win = null;
    open = false;
    submitModeBounds = null;
  }

  function hide() {
    stopDragTimer();
    if (!win || !open) return;
    open = false;
    dormant = false;
    disablePanelKeys();
    try { win.webContents.send('lc2:panel', { open: false }); } catch {}
    exitSearchFocus();
    keepOffTaskbar();
    if (USE_PANEL_SHADOW) panelShadow.fadeTo(0, FADE.outMs, () => panelShadow.hide());
    fadeOut(win, () => {
      try { win.hide(); } catch {}
      // 系统圆角模式绝不能碰 opacity（layered 会让 DWM 圆角/焦点失效）
      if (cornersMode === 'shape') {
        try { win.setOpacity(1); } catch {}
      }
      if (USE_PANEL_SHADOW) panelShadow.hide();
      log.debug?.('panel close');
    });
  }

  function toggle() {
    open ? hide() : show();
  }

  /* ---------------- 拖拽 ---------------- */
  function moveTo(x, y) {
    if (!win || win.isDestroyed()) return;
    const rx = Math.round(x), ry = Math.round(y);
    if (dragState && lastDragPos && lastDragPos[0] === rx && lastDragPos[1] === ry) return;
    lastDragPos = [rx, ry];
    // Windows 分数缩放下，setPosition 会把已舍入的当前尺寸写回，拖得越久窗口越大。
    // 复用上一次明确设定的 DIP 尺寸，避免每帧或每次拖拽累加舍入误差。
    win.setBounds({ x: rx, y: ry, ...windowSize }, false);
    dragMoveCount += 1;
  }

  function startDrag(payload) {
    if (!win) return;
    const p = payload || {};
    if (!Number.isFinite(p.sx) || !Number.isFinite(p.sy)) return;
    const b = win.getBounds();
    dragState = { ox: p.sx - b.x, oy: p.sy - b.y };
    lastDragPos = [b.x, b.y];

    // getCursorScreenPoint 在不同 DPI 环境下可能是 DIP 或物理像素：
    // 用「与按下点（DIP）的误差」判断哪种解释正确
    try {
      const scale = screen.getPrimaryDisplay().scaleFactor || 1;
      const cp = screen.getCursorScreenPoint();
      const errDip = Math.hypot(cp.x / scale - p.sx, cp.y / scale - p.sy);
      const errRaw = Math.hypot(cp.x - p.sx, cp.y - p.sy);
      dragCursorScale = errDip < errRaw ? scale : 1;
    } catch { dragCursorScale = screen.getPrimaryDisplay().scaleFactor || 1; }

    // 拖拽期间隐藏阴影：阴影是独立分层窗口，跟随移动必然滞后/错位
    if (USE_PANEL_SHADOW) {
      try { panelShadow.hide(); } catch {}
    }
    try { win.setAlwaysOnTop(true, TOPMOST_LEVEL); } catch {}
    // helper 的拖拽流只用于「窗口外松开鼠标」的检测；位置改由主进程轮询
    try { panelShadow.dragStart(); } catch (e) { log('dragStart helper failed:', e.message); }

    // 主进程 120Hz 轮询光标并移动窗口（比 helper→stdout→IPC 更稳）
    stopDragTimer();
    dragTimer = setInterval(() => {
      if (!win || win.isDestroyed() || !dragState) { stopDragTimer(); return; }
      let cp;
      try { cp = screen.getCursorScreenPoint(); } catch { return; }
      if (!cp) return;
      moveTo(cp.x / dragCursorScale - dragState.ox, cp.y / dragCursorScale - dragState.oy);
    }, 8);
    log.debug?.('drag start panel=', b);
  }

  /** 原生光标流 → 面板位置（现在仅作兜底；主进程计时器接管时不双驱动） */
  function dragToPhysical(px, py) {
    if (dragTimer) return;
    if (!win || win.isDestroyed() || !dragState) return;
    const scale = screen.getPrimaryDisplay().scaleFactor || 1;
    moveTo(px / scale - dragState.ox, py / scale - dragState.oy);
  }

  function dragMoveFallback(payload) {
    // 位置更新以辅助进程的原生光标流为准；这里仅作兜底（如辅助进程不可用）
    if (!win || !dragState || dragState.native !== false) return;
    const p = payload || {};
    if (!Number.isFinite(p.sx) || !Number.isFinite(p.sy)) return;
    moveTo(p.sx - dragState.ox, p.sy - dragState.oy);
  }

  function stopResizeTimer() {
    if (resizeTimer) { clearInterval(resizeTimer); resizeTimer = null; }
  }

  function startResize(payload) {
    if (!win || win.isDestroyed()) return;
    const p = payload || {};
    if (!RESIZE_DIRS.has(p.dir) || !Number.isFinite(p.sx) || !Number.isFinite(p.sy)) return;
    stopResizeTimer();
    const b = { ...win.getBounds(), ...windowSize };
    try {
      const scale = screen.getPrimaryDisplay().scaleFactor || 1;
      const cp = screen.getCursorScreenPoint();
      const errDip = Math.hypot(cp.x / scale - p.sx, cp.y / scale - p.sy);
      const errRaw = Math.hypot(cp.x - p.sx, cp.y - p.sy);
      resizeCursorScale = errDip < errRaw ? scale : 1;
    } catch { resizeCursorScale = screen.getPrimaryDisplay().scaleFactor || 1; }
    resizeState = { dir: p.dir, start: b, sx: p.sx, sy: p.sy };
    if (USE_PANEL_SHADOW) { try { panelShadow.hide(); } catch {} }
    try { win.setAlwaysOnTop(true, TOPMOST_LEVEL); } catch {}
    resizeTimer = setInterval(() => {
      if (!win || win.isDestroyed() || !resizeState) { stopResizeTimer(); return; }
      let cp;
      try { cp = screen.getCursorScreenPoint(); } catch { return; }
      if (!cp) return;
      const cx = cp.x / resizeCursorScale, cy = cp.y / resizeCursorScale;
      const st = resizeState.start, dir = resizeState.dir;
      const dx = cx - resizeState.sx, dy = cy - resizeState.sy;
      let x = st.x, y = st.y, width = st.width, height = st.height;
      if (dir.includes('e')) width = st.width + dx;
      if (dir.includes('s')) height = st.height + dy;
      if (dir.includes('w')) { width = st.width - dx; x = st.x + dx; }
      if (dir.includes('n')) { height = st.height - dy; y = st.y + dy; }
      if (width < PANEL.w) { if (dir.includes('w')) x = st.x + st.width - PANEL.w; width = PANEL.w; }
      if (height < PANEL.h) { if (dir.includes('n')) y = st.y + st.height - PANEL.h; height = PANEL.h; }
      try {
        setWindowBounds({ x: Math.round(x), y: Math.round(y), width: Math.round(width), height: Math.round(height) });
      } catch {}
    }, 8);
  }

  function setSize(width, height) {
    if (!win || win.isDestroyed()) return;
    if (!Number.isFinite(width) || !Number.isFinite(height)) return;
    const b = win.getBounds();
    let w = Math.max(PANEL.w, Math.round(width));
    let h = Math.max(PANEL.h, Math.round(height));
    try {
      const wa = screen.getDisplayMatching(b).workArea;
      w = Math.min(w, wa.width - 20);
      h = Math.min(h, wa.height - 20);
    } catch {}
    const x = Math.round(b.x + (b.width - w) / 2);
    const y = Math.round(b.y + (b.height - h) / 2);
    setWindowBounds({ x, y, width: w, height: h });
    sessionSize = windowSize;
    applyShape();
  }

  function setSubmitMode(on) {
    if (!win || win.isDestroyed()) return;
    if (on) {
      if (submitModeBounds) return;
      const previous = { ...win.getBounds(), ...windowSize };
      const wa = screen.getDisplayMatching(previous).workArea;
      const width = Math.min(820, wa.width - 40);
      const height = Math.min(900, wa.height - 40);
      const x = Math.round(wa.x + (wa.width - width) / 2);
      const y = Math.round(wa.y + (wa.height - height) / 2);
      setWindowBounds({ x, y, width, height });
      submitModeBounds = previous;
    } else {
      if (!submitModeBounds) return;
      setWindowBounds(submitModeBounds);
      submitModeBounds = null;
    }
    applyShape();
  }

  function finalizeResize() {
    if (!resizeState) return;
    stopResizeTimer();
    resizeState = null;
    applyShape();
    const b = win && !win.isDestroyed() ? win.getBounds() : null;
    if (b) {
      sessionSize = windowSize;
      configStore.state.panel = { x: b.x, y: b.y };
      try { configStore.save(); } catch {}
      log.debug?.('panel resized ->', windowSize.width, windowSize.height);
    }
    try { win.setAlwaysOnTop(true, TOPMOST_LEVEL); } catch {}
  }

  function finalizeDrag() {
    if (!win || win.isDestroyed() || !dragState) return;
    // 最后一帧对齐：松开时可能还有 1 帧未应用
    try {
      const cp = screen.getCursorScreenPoint();
      if (cp) moveTo(cp.x / dragCursorScale - dragState.ox, cp.y / dragCursorScale - dragState.oy);
    } catch {}
    stopDragTimer();
    try { panelShadow.dragStop(); } catch {}
    dragState = null;
    lastDragPos = null;
    dragMoveCount = 0;
    const b = win.getBounds();
    configStore.state.panel = { x: b.x, y: b.y };
    try { configStore.save(); } catch (e) { log('save panel pos failed:', e.message); }
    log.debug?.('panel moved ->', b.x, b.y);
    try {
      win.setAlwaysOnTop(true, TOPMOST_LEVEL);
      if (USE_PANEL_SHADOW) {
        panelShadow.setAlpha(255);
        panelShadow.showAt(b.x - SHADOW_PAD, b.y - SHADOW_PAD);
      }
      setTimeout(() => {
        if (!win || win.isDestroyed()) return;
        const nb = win.getBounds();
        if (USE_PANEL_SHADOW) panelShadow.moveTo(nb.x - SHADOW_PAD, nb.y - SHADOW_PAD);
        try { win.setAlwaysOnTop(true, TOPMOST_LEVEL); } catch {}
      }, 120);
    } catch (e) {
      log('drag end resync failed:', e.message);
    }
  }

  /* ---------------- 外部点击 ---------------- */
  /** 全局左键点击：点在面板与气泡之外 → 收起面板（popover 行为） */
  function handleOutsideClick(px, py) {
    if (!open || !win) return;
    const scale = screen.getPrimaryDisplay().scaleFactor || 1;
    const x = px / scale;
    const y = py / scale;

    const pb = win.getBounds();
    const inPanel = x >= pb.x && x <= pb.x + pb.width && y >= pb.y && y <= pb.y + pb.height;

    const bb = getBubbleBounds();
    const pad = 6;
    const inBubble =
      x >= bb.x - pad && x <= bb.x + bb.width + pad && y >= bb.y - pad && y <= bb.y + bb.height + pad;

    if (inPanel || inBubble) return;
    log.debug?.('outside click: pinned =', pinned);
    if (pinned) {
      // 置顶模式：点击外部不收起，但进入休眠（停止接收键盘）
      enterDormant();
      return;
    }
    hide();
  }

  /* ---------------- 置顶 ---------------- */
  function setPinned(v) {
    pinned = !!v;
    configStore.state.panelPinned = pinned;
    try { configStore.save(); } catch (e) { log('save pinned failed:', e.message); }
    if (win && !win.isDestroyed()) win.webContents.send('lc2:pin', pinned);
    log.debug?.('pin toggle →', pinned);
    return pinned;
  }

  /* ---------------- 创建 ---------------- */
  function create() {
    windowSize = { width: PANEL.w, height: PANEL.h };
    win = new BrowserWindow({
      width: PANEL.w,
      height: PANEL.h,
      transparent: false,
      backgroundColor: '#191120',
      frame: false,
      thickFrame: false,
      roundedCorners: true,
      resizable: false,
      skipTaskbar: true,
      hasShadow: false,
      focusable: false,
      alwaysOnTop: true,
      show: false,
      webPreferences: {
        preload: paths.preload,
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: false,
      },
    });
    win.on('resize', () => { applyShape(); });


    win.setAlwaysOnTop(true, TOPMOST_LEVEL);
    try { win.setBackgroundColor('#15161c'); } catch {}

    win.webContents.on('console-message', (_e, level, message) => {
      if (level >= 2) log('[renderer]', message);
      else log.debug?.('[renderer]', message);
    });
    Promise.resolve(win.loadFile(paths.rendererIndex, { query: { mode: 'panel', win: WIN_MODE } })).then(
      () => onPageLoaded?.(true),
      (error) => {
        if (isQuitting()) return;
        log('面板页面加载失败:', error.message);
        onPageLoaded?.(false);
      },
    );
    setupCorners();
    win.once('ready-to-show', () => applyShape());
    win.webContents.once('did-finish-load', () => applyShape());
    // 开发热部署时渲染层会重载：重载后把当前开合/置顶状态重新下发
    win.webContents.on('did-finish-load', () => sendPanelState());
    // 面板不销毁，只隐藏，避免反复重建
    win.on('blur', () => {
      log.debug?.('panel blur');
      enterDormant();
    });
    win.on('focus', () => {
      log.debug?.('panel focus');
      keepOffTaskbar();
    });
    win.on('close', (e) => {
      if (!isQuitting()) {
        e.preventDefault();
        hide();
      }
    });

    return win;
  }

  return {
    create,
    show,
    hide,
    toggle,
    getWindow: () => win,
    destroy,
    startResize,
    setSize,
    setSubmitMode,
    finalizeResize,
    isOpen: () => open,
    isPinned: () => pinned,
    isDormant: () => dormant,
    setPinned,
    togglePin: () => setPinned(!pinned),
    // 位置 / 拖拽
    moveTo,
    startDrag,
    dragToPhysical,
    dragMoveFallback,
    finalizeDrag,
    // 交互
    handleOutsideClick,
    wake,
    setSearchFocus,
    // 圆角 / 形状（原生 helper 重启后重探）
    applyShape,
    setupCorners,
    onNativeRestart: () => {
      cornersMode = null;
      setupCorners();
    },
  };
}

module.exports = createPanel;
