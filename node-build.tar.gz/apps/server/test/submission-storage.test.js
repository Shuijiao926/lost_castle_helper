'use strict';

/**
 * 投稿持久化单元测试：用假 Prisma Client 验证参数绑定、错误映射与只读边界。
 * 不连接真实数据库，也不执行任何迁移。
 */

const test = require('node:test');
const assert = require('node:assert/strict');

const { PostgresSubmissionRepository } = require('../src/modules/submissions/infrastructure/postgres-submission-repository');
const { Submission, SubmissionStatus } = require('../src/modules/submissions/domain/submission');
const { ReviewSubmission } = require('../src/modules/submissions/application/use-cases');
const { ConflictError } = require('../src/shared/kernel/errors');

const UUID = '7c1a4d2e-9b3f-4a51-8d60-2f5e9a7b1c33';

function makeSubmission(overrides = {}) {
  return new Submission({
    id: UUID,
    buildId: 'build_demo',
    payload: { id: 'build_demo', name: '演示流派', wt: 'THW', insc: 'insc_demo' },
    author: '玩家',
    sourceType: 'authorized-submission',
    licenseAccepted: true,
    files: [],
    status: SubmissionStatus.PENDING,
    ...overrides,
  });
}

test('save：把待审记录插入 player.submission，并附带内容指纹', async () => {
  const calls = [];
  const client = {
    async $executeRaw(strings, ...values) {
      calls.push({ sql: strings.join('?'), values });
      return 1;
    },
  };
  const repository = new PostgresSubmissionRepository(client);
  const submission = makeSubmission();

  await repository.save(submission);

  assert.equal(calls.length, 1);
  assert.match(calls[0].sql, /INSERT INTO player\.submission/);
  assert.ok(calls[0].values.includes('PENDING'), '待审状态必须作为参数写入');
  const hash = calls[0].values.find((value) => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value));
  assert.ok(hash, '必须写入 64 位内容指纹');
});

test('save：同流派已有待审时把唯一冲突转成业务冲突', async () => {
  const client = {
    async $executeRaw() {
      throw Object.assign(new Error('duplicate key'), { meta: { code: '23505' } });
    },
  };
  const repository = new PostgresSubmissionRepository(client);

  await assert.rejects(() => repository.save(makeSubmission()), ConflictError);
});

test('findById：非 UUID 直接按未找到处理，不发起查询', async () => {
  let queried = false;
  const client = {
    async $queryRaw() {
      queried = true;
      return [];
    },
  };
  const repository = new PostgresSubmissionRepository(client);

  assert.equal(await repository.findById('sub_000001'), null);
  assert.equal(queried, false);
});

test('listPending：行数据还原成仓储记录，时间转成 ISO 文本', async () => {
  const client = {
    async $queryRaw() {
      return [{
        id: UUID,
        build_id: 'build_demo',
        status: 'PENDING',
        author: '玩家',
        contact: null,
        source: null,
        source_type: 'authorized-submission',
        license_accepted: true,
        files: '[]',
        payload: JSON.stringify({ id: 'build_demo', name: '演示流派' }),
        review_note: null,
        reviewed_by: null,
        submitted_at: new Date('2026-11-19T09:00:00.000Z'),
        reviewed_at: null,
      }];
    },
  };
  const repository = new PostgresSubmissionRepository(client);

  const [record] = await repository.listPending();

  assert.equal(record.buildId, 'build_demo');
  assert.deepEqual(record.files, []);
  assert.equal(record.payload.name, '演示流派');
  assert.equal(record.createdAt, '2026-11-19T09:00:00.000Z');
  assert.equal(record.reviewedAt, null);
});

test('审核：流派改由 Java 维护后，Node 入口直接拒绝', async () => {
  const review = new ReviewSubmission({
    submissionRepository: { findById: async () => { throw new Error('不应读取仓储'); } },
    buildRepository: {},
    catalogRepository: {},
    submissionReviewOwner: 'java',
  });

  await assert.rejects(() => review.execute({ id: UUID, decision: 'approve' }), ConflictError);
});
