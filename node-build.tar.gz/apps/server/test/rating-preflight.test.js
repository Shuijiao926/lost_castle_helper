'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { Prisma } = require('@prisma/client');

const source = fs.readFileSync(path.join(__dirname, '../src/check-rating-storage.js'), 'utf8');

/** 隔离 CLI 的进程输出，使用真实 Prisma 异常验证错误分类，不访问正式数据库。 */
async function preflight({ failure, failWriter = false, configured = true } = {}) {
  const output = [];
  let clients = 0;
  let disconnected = 0;
  class FakeClient {
    constructor() { this.writer = clients++ === 1; }
    async $connect() {
      if (failure instanceof Prisma.PrismaClientInitializationError && this.writer === failWriter) throw failure;
    }
    async $queryRaw() {
      if (failure && this.writer === failWriter) throw failure;
      return [this.writer
        ? { database: 'lc2', role: 'writer', can_rate: true, can_read_raw: false,
          can_insert_raw: false, can_update_raw: false, can_change_build: false }
        : { database: 'lc2', role: 'reader', rated_builds: 0, can_rate: false }];
    }
    async $disconnect() { disconnected++; }
  }
  const process = {};
  await vm.runInNewContext(source, {
    require(name) {
      if (name === '@prisma/client') return { PrismaClient: FakeClient };
      if (name === './app/config') return configured ? { databaseUrl: 'reader', ratingsDatabaseUrl: 'writer' } : {};
      throw new Error('Unexpected module');
    },
    console: { log: (line) => output.push(line), error: (line) => output.push(line) },
    process,
  });
  assert.equal(output.length, 1);
  return { result: JSON.parse(output[0]), output: output[0], exitCode: process.exitCode, disconnected };
}

test('评分预检：读取账号连接错误保留 Prisma 初始化错误码', async () => {
  const checked = await preflight({
    failure: new Prisma.PrismaClientInitializationError('secret-reader-password', '6', 'P1001'),
  });
  assert.equal(checked.result.code, 'P1001');
  assert.equal(checked.result.stage, 'reader-connect');
  assert.equal(checked.exitCode, 1);
  assert.equal(checked.disconnected, 2);
  assert.ok(!checked.output.includes('secret-reader-password'));
});

test('评分预检：写账号密码错误准确标记写连接阶段', async () => {
  const checked = await preflight({ failWriter: true,
    failure: new Prisma.PrismaClientInitializationError('secret-writer-password', '6', 'P1000') });
  assert.equal(checked.result.code, 'P1000');
  assert.equal(checked.result.stage, 'writer-connect');
  assert.ok(!checked.output.includes('secret-writer-password'));
});

test('评分预检：SQL 权限错误保留 PostgreSQL 错误码', async () => {
  const checked = await preflight({ failure: new Prisma.PrismaClientKnownRequestError('secret-query', {
    code: 'P2010', clientVersion: '6', meta: { code: '42501' },
  }) });
  assert.equal(checked.result.code, '42501');
  assert.ok(!checked.output.includes('secret-query'));
});

test('评分预检：未知异常的消息和不可信错误码不输出', async () => {
  const checked = await preflight({ failure: Object.assign(new Error('secret-message'), { code: 'secret-code' }) });
  assert.equal(checked.result.code, 'CHECK_FAILED');
  assert.ok(!checked.output.includes('secret-'));
});

test('评分预检：缺少连接配置时不创建数据库客户端', async () => {
  const checked = await preflight({ configured: false });
  assert.equal(checked.result.code, 'MISSING_CONNECTION');
  assert.equal(checked.result.stage, 'configuration');
  assert.equal(checked.disconnected, 0);
});

test('评分预检：有效的独立账号配置保留成功输出', async () => {
  const checked = await preflight();
  assert.equal(checked.result.ok, true);
  assert.equal(checked.result.ratingWrite, true);
  assert.equal(checked.result.buildsWithRatings, 0);
  assert.equal(checked.disconnected, 2);
  assert.equal(checked.exitCode, undefined);
});
